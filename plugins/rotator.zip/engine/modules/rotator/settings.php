<?php

$settings = array(

  'banner1' => array(
	'os=windows xp,windows vista,windows 7,windows 8,windows 8.1,windows 10;country=ru,by,uz,md,cz,am,kg,kz,tj,az,ge,ua' => array(
    'Баннер реклама><!--/noindex-->',
    'Баннер реклама2><!--/noindex-->',
  ),

	'os=windows xp,windows vista,windows 7,windows 8,windows 8.1,windows 10;country=ru,ua,by,uz,md,cz,am,kg,kz,tj,az,ge' 
	    => array(
             '<!--noindex--><a href="http://apache-web.biz/go-home.php?sid=12&{name}" ><img src="/templates/officeapplications/images/images-10.png" alt=""></a><!--/noindex-->',
             'is adblock'
   ),	
	
		'' => 'тут гугл'
    
  ),
  

'banner2' => array(
	'os=windows xp,windows vista,windows 7,windows 8,windows 8.1,windows 10;country=ru,by,uz,md,cz,am,kg,kz,tj,az,ge,ua' => array(
    'Баннер реклама22><!--/noindex-->',
    'Баннер реклама222><!--/noindex-->',
  ),

	'os=windows xp,windows vista,windows 7,windows 8,windows 8.1,windows 10;country=ru,ua,by,uz,md,cz,am,kg,kz,tj,az,ge' 
	    => array(
             '<!--noindex--><a href="http://apache-web.biz/go-home.php?sid=12&{name}" ><img src="/templates/officeapplications/images/images-10.png" alt=""></a><!--/noindex-->',
             'is adblock'
   ),	
	
		'' => 'тут гугл'
    
  ),

);  