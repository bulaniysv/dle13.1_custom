<?php

if (!defined('DATALIFEENGINE') || !defined('LOGGED_IN')) {
	die('Hacking attempt!');
}
/**
 * @global $member_id
 */

define('MODULE_DIR', ENGINE_DIR . '/modules/redirect');

echoheader('Redirect', 'Redirect — редирект с таймаутом');

include MODULE_DIR . '/admin/main.php';

echofooter();