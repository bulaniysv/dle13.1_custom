<?PHP
/*
=====================================================
 DataLife Engine - by SoftNews Media Group
-----------------------------------------------------
 http://dle-news.ru/
-----------------------------------------------------
 Copyright (c) 2004,2015 SoftNews Media Group
=====================================================
 Данный код защищен авторскими правами
=====================================================
 Файл: help.php
-----------------------------------------------------
 Назначение: помощь
=====================================================
*/
if (!defined('DATALIFEENGINE')) {
    die("Hacking attempt!");
}

echoheader("REDIRECT TIMEOUT", "Redirect with timeout");

echo '
    <form action="" method="POST">
        <div class="panel panel-default systemsettings">
          <div class="panel-heading">Настройка модуля Redirect with timeout</div>
';

$fileexec = '<?php $config = unserialize(file_get_contents("redirect_config.cfg")); if (!isset($_GET["hash"]) || empty($_GET["hash"])) { echo "internal error"; die(); } $_GET["hash"] = str_replace(" ","+",$_GET["hash"]); $hash = base64_decode(($_GET["hash"])); $ex = explode("%%%", $hash); $url = $ex[0]; $title = $ex[1]; $timeout = $config["timeout"] ?>';
$module_config = unserialize(file_get_contents('redirect_config.cfg'));
$module_config['filecontent'] = @file_get_contents($module_config['filename']);
$module_config['filecontent'] = preg_replace('/<\?php \$config(.*?)\?>/','',$module_config['filecontent']);
if(isset($_POST['save'])) {
    foreach($_POST['fields'] as $field) {
        $fields[$field]['value'] = true;
    }
	  foreach($_POST['transmit'] as $field) {
        $fields[$field]['transmit'] = true;
    }
    $_config['fields'] = $fields;
    $_config['attach'] = $_POST['attach'];
    $_config['timeout'] = $_POST['timeout'];
    $_config['filename'] = $_POST['filename'];
    $_config['off'] = $_POST['off'];
	$_config['ubar'] = $_POST['ubar'];
	$_config['ubarId'] = $_POST['ubarId'];
	$_config['ubarImg'] = $_POST['ubarImg'];
    $_config['url'] = $config['http_home_url'].$_POST['url'];
    if($module_config['filename']!=$_POST['filename'] || !file_exists($_POST['filename'])) {
        @unlink($module_config['filename']);
    }
    file_put_contents($_POST['filename'],$fileexec."".$_POST['filecontent']);
    file_put_contents('redirect_config.cfg',serialize($_config));
    header("Location: ".$_SERVER['REQUEST_URI']);
}

echo '
<table class="table table-striped">
<tr>
<td class="col-xs-6"><h6 class="media-heading text-semibold">Отключить редирект:</h6></td>
<td class="col-xs-6">
    <input class="switch" type="checkbox" name="off" value="1" style="display: none;" '.($module_config['off'] ? 'checked' : '').'>
</td>
</tr>
<tr>
<td class="col-xs-6"><h6 class="media-heading text-semibold">Использовать uBar:</h6></td>
<td class="col-xs-6">
    <input class="switch" type="checkbox" name="ubar" value="1" style="display: none;" '.($module_config['ubar'] ? 'checked' : '').'>
</td>
</tr>
<tr>
<td class="col-xs-6">
    <h6 class="media-heading text-semibold">ID для uBar:</h6>
    <span class="text-muted text-size-small">Заполнять в том случае, если используется uBar</span>
</td>
<td class="col-xs-6">
    <input type="text" class="form-control" name="ubarId" value="'.$module_config['ubarId'].'">
</td>
</tr>
<tr>
<td class="col-xs-6">
<h6 class="media-heading text-semibold">Картинка для uBar:</h6>
<span class="text-muted text-size-small">Заполнять в том случае, если используется uBar</span>
</td>
<td class="col-xs-6">
<input type="text" class="form-control" name="ubarImg" value="'.$module_config['ubarImg'].'">
</td>
</tr>
<table class="table table-striped">
<tr>
<td class="col-xs-6">
<h6 class="media-heading text-semibold">Редирект:</h6>
<span class="text-muted text-size-small">Дополнительное поле, содержащее ссылку на которую производится перенаправление</span>
</td>
<td class="col-xs-6">
<script>
$(document).ready(function() {
    $(".fields-list").chosen({no_results_text: "Oops, nothing found!"});
});
</script>
<select data-placeholder="Выберите поля" multiple class="fields-list" name="fields[]">';
$xfields = xfieldsload();
$transmit = '';
foreach($xfields as $xf) {
  $transmit .= '<input type="checkbox" name="transmit[]" value="'.$xf[0].'" checked style="display:none" />';
	echo '<option value="'.$xf[0].'" '.($module_config['fields'][$xf[0]]['value'] ? 'selected' : '').'>'.$xf[0].'</option>';
}
echo '</select>'.$transmit.'</td></tr></table>

<table class="table table-striped">
<tr>
<td class="col-xs-6">
<h6 class="media-heading text-semibold">Задержка редиректа:</h6>
<span class="text-muted text-size-small">Через сколько секунд пользователю отдавать файл</span>
</td>
<td class="col-xs-6">
 <input type="text" class="form-control" name="timeout" value="'.$module_config['timeout'].'" />
</td>
</tr>
<tr>
<td class="col-xs-6">
<h6 class="media-heading text-semibold">URL редиректа:</h6>
<span class="text-muted text-size-small">По умолчанию <strong>redirect.html</strong></span>
</td>
<td class="col-xs-6">
 <input type="text" class="form-control" name="url" value="'.str_replace($config['http_home_url'], '', $module_config['url']).'" />
</td>
</tr>
<!--Страница редиректа: <input type="text" name="filename" value="'.$module_config['filename'].'" />-->
<!--<textarea name="filecontent" style="height:300px;width: 100%;">'.$module_config['filecontent'].'</textarea>-->
</table>
</div>
<div class="clearfix">
<div style="margin-bottom:30px;">
<button type="submit" name="save" class="btn bg-teal btn-raised position-left legitRipple"><i class="fa fa-floppy-o position-left"></i> Сохранить</button>
</div>
</div>
</form>';

echofooter();

?>