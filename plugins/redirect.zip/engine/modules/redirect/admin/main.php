<?php
if (!defined('DATALIFEENGINE') || !defined('LOGGED_IN')) {
	die('Hacking attempt!');
}
?>

<script>
	<!--
		function ChangeOption(obj, selectedOption) {

			$("#navbar-filter li").removeClass('active');
			$(obj).parent().addClass('active');
			document.getElementById('general').style.display = "none";
			document.getElementById('docs').style.display = "none";
			document.getElementById(selectedOption).style.display = "";

			return false;

		}
//-->
</script>

<div class="navbar navbar-default navbar-component navbar-xs systemsettings">
	<ul class="nav navbar-nav visible-xs-block">
		<li class="full-width text-center">
			<a data-toggle="collapse" data-target="#navbar-filter" class="legitRipple"><i class="fa fa-bars"></i></a>
		</li>
	</ul>
	<div class="navbar-collapse collapse" id="navbar-filter">
		<ul class="nav navbar-nav">
			<li class="active"><a onclick="ChangeOption(this, 'general');" class="tip legitRipple" title="" data-original-title="Общие настройки"><i class="fa fa-cog"></i> Общие настройки</a></li>
			<li><a onclick="ChangeOption(this, 'docs');" class="tip legitRipple" title="" data-original-title="Справочная информация"><i class="fa fa-file-text-o"></i> Справочная информация</a></li>
		</ul>
	</div>
</div>

<div id="general">
	<?php include MODULE_DIR . '/admin/settings.php'; ?>
	<div class="alert alert-warning alert-styled-left alert-arrow-left alert-component">
		<b style="margin-bottom:10px;">Внимание:</b><br>
		<p>Для корректной работы модуля необходимо добавить изменениe в корневой файл <b>.htaccess</b></p>
		<p>Найти:</p>
<pre>RewriteRule ^statistics.html$ index.php?do=stats [L]</pre>
		<p>После добавить:</p>
<pre>RewriteRule ^redirect.html$ index.php?do=redirect [L]</pre>
	</div>
</div>
<div id="docs" style="display: none;">
	<?php include MODULE_DIR . '/admin/docs.php'; ?>
</div>