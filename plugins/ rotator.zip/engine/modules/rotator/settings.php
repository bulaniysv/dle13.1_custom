<?php

$settings = array(

  'banner1' => array(

	'os=windows xp,windows vista,windows 7,windows 8,windows 8.1,windows 10,Mac OS X'
	    => array(
             '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- skype -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-9764971761641225"
     data-ad-slot="5098628642"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>',
             '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- skype -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-9764971761641225"
     data-ad-slot="5098628642"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>'
   ),	
	
		'' => '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- skype -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-9764971761641225"
     data-ad-slot="5098628642"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>'
    
  ),
  



);  