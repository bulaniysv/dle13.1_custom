<?php
	if (!defined('DATALIFEENGINE') || !defined('LOGGED_IN')) {
	    die('Hacking attempt!');
	}
?>

<ol>
	<li><b>{year}</b> - выводит текущий год</li>
	<li><b>{this_uri}</b> - URL текущей страницы</li>
	<li><b>fullstory Open Graph</b> - description, image (доп. поле logo)</li>
	<li><b>category Open Graph</b> - site_name, type, title, description, url, image</li>
	<li>https://github.com/n0wheremany/Request-Tag</li>
</ol>
